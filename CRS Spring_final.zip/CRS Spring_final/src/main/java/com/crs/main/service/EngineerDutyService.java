package com.crs.main.service;

import com.crs.main.model.EngineerDuty;

public interface EngineerDutyService {
	void saveEngineerDuty (EngineerDuty engineerDuty);

}
